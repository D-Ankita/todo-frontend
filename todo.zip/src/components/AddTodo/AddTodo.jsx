function AddTodo() {
  return (
    <div>
      <input type="text" placeholder="Enter task" />
      <button>+</button>
    </div>
  );
}

export default AddTodo