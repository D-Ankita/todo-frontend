import Task from "../Task/Task";

function Tasklist({ todos }) {
  return (
    <div>
      {/* !props.TaskList : <h1>Loading...</h1> ? return */}
     
      {todos.map((todo) => {
        return <Task todo={todo} />
      })}
    </div>
  );
}

export default Tasklist;
