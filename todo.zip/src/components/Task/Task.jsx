
function Task({todo}){
    const {id , description} = todo
    return <div>
        <input value={description} disabled id ={id}/>
        <button> Edit </button>
        <button>Delete</button>
    </div>
}

export default Task;