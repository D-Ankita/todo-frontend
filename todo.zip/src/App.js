import logo from "./logo.svg";
import "./App.css";
import { useEffect, useState } from "react";
import Tasklist from "./components/Tasklist/Tasklist";
import AddTodo from "./components/AddTodo/AddTodo";

const baseurl = "http://localhost:4000"
function App() {

  const [inputTask , setInputTask] = useState("");
  const [taskList , setTaskList] = useState([])
  useEffect(() => {
    fetch(`${baseurl}/todos`)
    .then((response) => response.json())
    .then((data) => {
      // console.log("data",data);
      setTaskList([...data.data])
    })
  }, []);

  useEffect(() => {
   console.log(taskList);
  }, [taskList]);
  return <div className="App">
    <input type="text" placeholder="Enter task" />
      <button>+</button>
    {/* <AddTodo/> */}
    <Tasklist todos = {taskList}/>
  </div>;
}

export default App;
